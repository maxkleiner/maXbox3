ExportDemo.dpr
--------------

- Needs Delphi 2 or higher.
- Demonstrates export to files and to the clipboard using the TSynExporterHTML
  and TSynExporterRTF components.

