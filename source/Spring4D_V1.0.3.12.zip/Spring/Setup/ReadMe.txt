Thanks to FinalBuilder, we use FinalBuilder to build all versions and verfiy all unit tests.
For more information about FinalBuilder, visit http://www.finalbuilder.com