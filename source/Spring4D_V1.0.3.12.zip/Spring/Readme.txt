==========================================

Spring Framework for Delphi 

Copyright (c) 2009-2012 Spring4D Team

http://www.spring4d.org

==========================================

Spring Framework for Delphi (Spring4D) is an open-source code library for Embarcadero Delphi 2010+ platforms. It consists of a number of different modules, including a Dependency Injection Framework and a Base Class Library (Common Types, Collections Framework, Reflection, Logging).

To Build the framework, Run Build.exe

To Browse the framework, open the corresponding project group in the Packages folder

To Get the latest information, please visit http://www.spring4d.org