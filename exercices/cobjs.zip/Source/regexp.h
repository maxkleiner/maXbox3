/***************************************************************************/
/*                                                                         */
/* regexp.h                                                                */
/*                                                                         */
/* Copyright (c) 1986 by Univerisity of Toronto                            */
/*                                                                         */
/* This public domain file was originally written by Henry Spencer for the */
/* University of Toronto and was modified and reformatted by Rudy Velthuis */
/* for use with Borland C++ Builder 5.                                     */
/*                                                                         */
/***************************************************************************/

#ifndef REGEXP_H
#define REGEXP_H

#define RE_OK                   0
#define RE_NOTFOUND             1
#define RE_INVALIDPARAMETER     2
#define RE_EXPRESSIONTOOBIG     3
#define RE_OUTOFMEMORY          4
#define RE_TOOMANYSUBEXPS       5
#define RE_UNMATCHEDPARENS      6
#define RE_INVALIDREPEAT        7
#define RE_NESTEDREPEAT         8
#define RE_INVALIDRANGE         9
#define RE_UNMATCHEDBRACKET     10
#define RE_TRAILINGBACKSLASH    11
#define RE_INTERNAL             20
#define RE_NOPROG               30
#define RE_NOSTRING             31
#define RE_NOMAGIC              32
#define RE_NOMATCH              33
#define RE_NOEND                34
#define RE_INVALIDHANDLE        99

#define NSUBEXP  10

/*
 * The first byte of the regexp internal "program" is actually this magic
 * number; the start node begins in the second byte.
 */
#define	MAGIC	0234

#pragma pack(push, 1)

typedef struct regexp
{
    char *startp[NSUBEXP];
    char *endp[NSUBEXP];
    char regstart;              /* Internal use only. */
    char reganch;               /* Internal use only. */
    char *regmust;              /* Internal use only. */
    int regmlen;                /* Internal use only. */
    char program[1];            /* Internal use only. */
} regexp;

#ifdef __cplusplus
extern "C" {
#endif

extern int regerror;
extern regexp *regcomp(char *exp);
extern int regexec(register regexp* prog, register char *string);
extern int reggeterror(void);
extern void regseterror(int err);
extern void regdump(regexp *exp);

#ifdef __cplusplus
}
#endif


#pragma pack(pop)

#endif // REGEXP_H
